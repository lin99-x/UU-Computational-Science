import matplotlib.pyplot as plt

# number of threads
x = [1, 2, 4, 8, 12, 16, 20, 24]

# time
y = [1.056635, 0.537080, 1.653542, 1.892725, 1.934547, 0.454025, 0.523835, 0.466742]

speeduplst = []

for i in range(len(y)):
    speedup = y[0] / y[i]
    speeduplst.append(speedup)
    
plt.plot(x, speeduplst, 'ro')
plt.show()