#define G 70

void print_pyramid(int pyramidSize);
